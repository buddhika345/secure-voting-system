CREATE DATABASE My_voting_System;

USE My_voting_System;

CREATE TABLE voted (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255),
    vote_option VARCHAR(100),
    ip_address VARCHAR(45),
    user_agent TEXT,
    timestamp DATETIME
);
