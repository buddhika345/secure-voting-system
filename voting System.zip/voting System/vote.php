<?php
header('Content-Type: application/json');
include 'db.php';

$email = $_POST['email'];
$vote = $_POST['vote_option'];
$ip = $_SERVER['REMOTE_ADDR'];
$agent = $_SERVER['HTTP_USER_AGENT'];
$timestamp = date("Y-m-d H:i:s");

//Limit Votes per IP per Day

$check_sql = "SELECT COUNT(*) FROM voted WHERE ip_address = ? AND DATE(timestamp) = CURDATE()";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("s", $ip);
$check_stmt->execute();
$check_stmt->bind_result($count);
$check_stmt->fetch();
$check_stmt->close();

if ($count >= 1) {
    echo json_encode(["status" => "error", "message" => "You already voted today from this IP."]);
    exit;
}



$sql = "INSERT INTO voted (email, vote_option, ip_address, user_agent, timestamp)
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $email, $vote, $ip, $agent, $timestamp);
$stmt->execute();

header("Location: vote_success.html");
exit;
?>
